package com.mogli.impprojekt.commands;

import com.mogli.impprojekt.Main;
import com.mogli.impprojekt.utils.ConfigManager;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Properties;
import java.util.stream.Stream;

public class CommandManager {

    private HashMap<String, Command> commands;
    private ConfigManager configManager;

    public CommandManager() throws IOException {
        configManager = Main.getConfigManager();
        commands = new HashMap<>();
    }

    public boolean runCommand(String command) throws IOException {
        if(command.startsWith((String) configManager.get("prefix"))) {
            String[] splittedCommand = command.split(" ");
            String cmd = splittedCommand[0].replace((CharSequence) configManager.get("prefix"), "");

            String argsString = "";

            for (int i = 0; i < splittedCommand.length; i++) {

                if(splittedCommand.length > 1) {
                    if(i == 1) {
                        System.out.println(splittedCommand[i]);
                    }
                    argsString = argsString + " " + splittedCommand[i];
                    System.out.println(argsString);
                } else {
                    break;
                }


            }

            String[] args = argsString.split(" ");

            System.out.println("arg 0" + args[0]);
            System.out.println("length" + args.length);
            if(commands.containsKey(cmd)) {
                commands.get(cmd).onCommand(args);
            }

        }

        return false;
    }

    public void registerCommand(String commandName, Command command) throws InterruptedException {
        commands.put(commandName, command);
        System.out.println("[COMMANDS] " + command.getClass().getName() + " registered.");
        Thread.sleep(200);
    }



}
